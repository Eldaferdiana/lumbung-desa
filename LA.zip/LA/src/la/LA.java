/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package la;

import com.telkom.mwallet.controller.ControllerKey;
import java.util.Calendar;

/**
 *
 * @author raden
 */
public class LA {

    /**
     * @param args 
     */
    
    public static void main(String[] args) {
        ControllerKey ck = new ControllerKey();
        System.out.println("apiBaseUrl() -> "+ck.apiBaseURL());
        System.out.println("encryptHmacRaw() -> "+ck.encryptHmacRaw(String.valueOf(Long.valueOf(Calendar.getInstance().getTimeInMillis())), "707e064da9a11ea3", "611014838854858", "p", "p", "p", "p", "3.2.0"));
    }
    
}

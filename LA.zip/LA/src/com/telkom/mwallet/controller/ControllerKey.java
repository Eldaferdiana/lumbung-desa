/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.telkom.mwallet.controller;

/**
 *
 * @author raden
 */
public final class ControllerKey {
    static {
        System.out.println(System.getProperty("java.library.path"));
        System.loadLibrary("CredentialKey");
        System.loadLibrary("HappyBus");
        System.out.println("library loaded successfully");  
    }
    
    public final native String apiBaseURL();

    public final native String apiBaseURLDev();

    public final native String apiSessionURL();

    public final native String apiSuggestionURL();

    public final native String apiWalktroughURL();

    public final native String decryptJson(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8);

    public final native String encryptHmacRaw(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8);

    public final native String encryptHmacWar(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8);

    public final native String encryptJson(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8);

    public final native String encryptPlainText(String str, String str2, String str3);

    public final native String encryptionKEY();

    public final native String encryptionKEYQR();

    public final native int encryptionLength();

    public final native String hashMacUID();

    public final native String payload(String str, String str2);

    public final native String preferenceKey(String str);

    public final native String preferenceValueDecrypt(String str, String str2);

    public final native String preferenceValueEncrypt(String str, String str2);
}


